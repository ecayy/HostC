#include <stdio.h>
#include <stdint.h>
int main(void)

{
	uint64_t income;
	double taxrate
	uint64_t tax = income * taxrate/100;

	printf("Enter your income: ");
	fflush(stdout);
	scanf("%Iu",income);

	if (income <= 9525){
		tax = 0;


}
