#include <stdio.h>
int main(void)
{
	float number1, number2, number3;
		float average;

		printf("\nEnter the all numbers: ");

		scanf(" %f %f %f",&number1,&number2,&number3);


		average = (number1 + number2 + number3) / 3;
		printf("\nAverage is : %f\n",average);
		printf("Press Enter \n");
				while(getchar()!= '\n')
				{

				}
				getchar();

}
