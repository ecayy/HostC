#include <stdio.h>
int main(void)

{
	double number = -1.60217662e-19;
	printf("number = %0.28lf\n",number);
	printf("number = %0.8le\n",number);
	return 0;

}
